'use client'
import { useState } from 'react'
import toast from 'react-hot-toast'

const ALL_ORDERS = [
  { id: '#MG-847', client: 'Ion Popescu', address: 'Str. Eminescu 42', phone: '0721 234 567', items: 'Shaorma Pui ×2, Cola 0.5L', total: 61, time: '20:10', status: 'prep' },
  { id: '#MG-846', client: 'Maria Ion', address: 'Bd. Magheru 20', phone: '0732 567 890', items: 'Burger BBQ Grill, Cartofi prăjiți', total: 47, time: '19:52', status: 'done' },
  { id: '#MG-845', client: 'Andrei Niculescu', address: 'Str. Florilor 8', phone: '0741 890 123', items: 'Family Bucket Metropolitan', total: 149, time: '19:41', status: 'new' },
  { id: '#MG-844', client: 'Elena Mihăilescu', address: 'Calea Victoriei 55', phone: '0752 123 456', items: 'Meniu Duo Metropolitan, Sos Samurai ×2', total: 95, time: '19:30', status: 'prep' },
  { id: '#MG-843', client: 'Radu Georgescu', address: 'Str. Libertății 10', phone: '0761 345 678', items: 'Shaorma Mix ×3, Ayran ×3', total: 129, time: '19:11', status: 'done' },
  { id: '#MG-842', client: 'Ana Constantin', address: 'Bd. Unirii 30', phone: '0770 456 789', items: 'Burger Metropolitan, Inele ceapă', total: 52, time: '18:55', status: 'cancel' },
]

const STATUS_LABELS = {
  new: '◉ Nouă',
  prep: '⏳ Preparare',
  delivery: '🛵 Livrare',
  done: '✓ Livrat',
  cancel: '✕ Anulat',
}

const STATUS_STYLE = {
  new: 'bg-blue-900/20 text-blue-400 border-blue-800/30',
  prep: 'bg-yellow-900/20 text-yellow-400 border-yellow-800/30',
  delivery: 'bg-purple-900/20 text-purple-400 border-purple-800/30',
  done: 'bg-green-900/20 text-green-400 border-green-800/30',
  cancel: 'bg-red-900/20 text-red-400 border-red-800/30',
}

const NEXT_STATUS = { new: 'prep', prep: 'delivery', delivery: 'done' }

export default function AdminComenziPage() {
  const [orders, setOrders] = useState(ALL_ORDERS)
  const [filter, setFilter] = useState('all')

  const filtered = filter === 'all' ? orders : orders.filter(o => o.status === filter)

  const advanceStatus = (id) => {
    setOrders(prev => prev.map(o => {
      if (o.id !== id || !NEXT_STATUS[o.status]) return o
      const next = NEXT_STATUS[o.status]
      toast.success(`Comandă ${id} → ${STATUS_LABELS[next]}`)
      return { ...o, status: next }
    }))
  }

  const FILTERS = [
    { val: 'all', label: 'Toate' },
    { val: 'new', label: 'Noi' },
    { val: 'prep', label: 'Preparare' },
    { val: 'delivery', label: 'Livrare' },
    { val: 'done', label: 'Livrate' },
    { val: 'cancel', label: 'Anulate' },
  ]

  return (
    <div className="page-enter">
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-bebas text-4xl text-white">COMENZI</h1>
        <button
          onClick={() => toast.success('Export CSV generat!')}
          className="bg-gradient-to-r from-[#c0392b] to-[#96251e] text-white font-condensed font-bold text-sm uppercase tracking-wide px-5 py-2.5 rounded-xl hover:from-[#e74c3c] hover:to-[#c0392b] transition-all"
        >
          Export CSV
        </button>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 flex-wrap mb-6">
        {FILTERS.map(f => (
          <button
            key={f.val}
            onClick={() => setFilter(f.val)}
            className={`px-4 py-2 rounded-xl text-sm font-condensed font-bold uppercase tracking-wide transition-all border ${
              filter === f.val
                ? 'bg-[#c0392b] border-[#c0392b] text-white'
                : 'bg-transparent border-white/10 text-[#b8a99a] hover:border-white/20'
            }`}
          >
            {f.label}
            {f.val !== 'all' && (
              <span className="ml-2 text-xs opacity-70">
                {orders.filter(o => o.status === f.val).length}
              </span>
            )}
          </button>
        ))}
      </div>

      <div className="bg-[#1a1a1a] border border-white/8 rounded-[18px] overflow-hidden">
        <table className="admin-table w-full">
          <thead>
            <tr>
              <th>#</th>
              <th>Client</th>
              <th>Adresă</th>
              <th>Produse</th>
              <th>Total</th>
              <th>Ora</th>
              <th>Status</th>
              <th>Acțiuni</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(order => (
              <tr key={order.id}>
                <td className="text-[#f39c12] font-bold font-condensed">{order.id}</td>
                <td>
                  <div className="text-white text-sm font-medium">{order.client}</div>
                  <div className="text-[#7a6e66] text-xs">{order.phone}</div>
                </td>
                <td className="text-xs max-w-[120px] truncate">{order.address}</td>
                <td className="text-xs max-w-[160px] truncate">{order.items}</td>
                <td className="text-white font-bold">{order.total} lei</td>
                <td>{order.time}</td>
                <td>
                  <span className={`text-xs font-bold px-2.5 py-1 rounded-full border whitespace-nowrap ${STATUS_STYLE[order.status]}`}>
                    {STATUS_LABELS[order.status]}
                  </span>
                </td>
                <td>
                  <div className="flex gap-2">
                    {NEXT_STATUS[order.status] && (
                      <button
                        onClick={() => advanceStatus(order.id)}
                        className="text-xs bg-[#c0392b]/20 border border-[#c0392b]/30 text-[#e74c3c] px-3 py-1.5 rounded-lg hover:bg-[#c0392b]/30 transition-all whitespace-nowrap"
                      >
                        → {STATUS_LABELS[NEXT_STATUS[order.status]].split(' ').slice(1).join(' ')}
                      </button>
                    )}
                    <button
                      onClick={() => toast.success(`Detalii comandă ${order.id}`)}
                      className="text-xs border border-white/10 text-[#7a6e66] px-3 py-1.5 rounded-lg hover:text-white hover:border-white/20 transition-all"
                    >
                      Detalii
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="text-center py-16">
            <span className="text-5xl block mb-3">📭</span>
            <p className="text-[#7a6e66] font-condensed font-bold text-lg uppercase">Nicio comandă în această categorie</p>
          </div>
        )}
      </div>
    </div>
  )
}
