'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useCartStore } from '@/store/cartStore'
import { COUPONS } from '@/lib/data'
import toast from 'react-hot-toast'
import Footer from '@/components/layout/Footer'

const JUDETE = ['București', 'Ilfov', 'Prahova', 'Dâmbovița', 'Giurgiu', 'Călărași']

export default function CheckoutPage() {
  const router = useRouter()
  const { items, clearCart } = useCartStore()
  const [deliveryType, setDeliveryType] = useState('livrare')
  const [payMethod, setPayMethod] = useState('numerar')
  const [tip, setTip] = useState(5)
  const [couponCode, setCouponCode] = useState('')
  const [appliedCoupon, setAppliedCoupon] = useState(null)
  const [form, setForm] = useState({
    numeComplet: '', telefon: '', email: '',
    judet: 'București', localitate: 'București',
    strada: '', numar: '', bloc: '', scara: '', apartament: '', codInterfon: '',
    instructiuni: '', intervalOrar: 'cat-mai-curand',
  })

  const subtotal = items.reduce((s, i) => s + (i.promo || i.price) * i.qty, 0)
  const deliveryFee = deliveryType === 'ridicare' ? 0 : subtotal >= 80 ? 0 : 7
  const discountAmt = appliedCoupon ? Math.round(subtotal * appliedCoupon.discount) : 0
  const total = subtotal - discountAmt + deliveryFee + tip

  const applyCoupon = () => {
    const c = COUPONS[couponCode.toUpperCase()]
    if (c) { setAppliedCoupon(c); toast.success(`Cod ${couponCode.toUpperCase()} aplicat! ${c.label}`) }
    else toast.error('Cod promoțional invalid')
  }

  const handleOrder = (e) => {
    e.preventDefault()
    if (items.length === 0) { toast.error('Coșul este gol!'); return }
    clearCart()
    router.push('/confirmare')
  }

  const Field = ({ label, children }) => (
    <div>
      <label className="block text-xs font-bold uppercase tracking-wide text-[#7a6e66] mb-1.5">{label}</label>
      {children}
    </div>
  )

  const inputClass = "w-full bg-white/5 border border-white/8 text-white placeholder-[#7a6e66] rounded-xl py-3 px-4 text-sm focus:outline-none focus:border-[#c0392b]/50"

  return (
    <div className="page-enter pt-16">
      <div className="bg-[#111] border-b border-white/5 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <h1 className="font-bebas text-5xl sm:text-6xl text-white">FINALIZEAZĂ <span className="text-[#f39c12]">COMANDA</span></h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
        <form onSubmit={handleOrder}>
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-8 items-start">
            {/* Left col */}
            <div className="space-y-5">
              {/* Tip livrare */}
              <div className="bg-[#1a1a1a] border border-white/8 rounded-[18px] p-6">
                <h2 className="font-condensed font-bold text-lg uppercase tracking-wide text-white mb-5 pb-3 border-b border-white/8">Tip Livrare</h2>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { val: 'livrare', icon: '🛵', label: 'Livrare la adresă' },
                    { val: 'ridicare', icon: '🏪', label: 'Ridicare din local' },
                  ].map(opt => (
                    <button
                      key={opt.val} type="button"
                      onClick={() => setDeliveryType(opt.val)}
                      className={`flex flex-col items-center gap-2 py-5 rounded-xl border-2 transition-all ${deliveryType === opt.val ? 'border-[#c0392b] bg-[#c0392b]/10' : 'border-white/8 bg-white/3 hover:border-white/20'}`}
                    >
                      <span className="text-3xl">{opt.icon}</span>
                      <span className="text-sm font-semibold text-white">{opt.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Date livrare */}
              {deliveryType === 'livrare' && (
                <div className="bg-[#1a1a1a] border border-white/8 rounded-[18px] p-6">
                  <h2 className="font-condensed font-bold text-lg uppercase tracking-wide text-white mb-5 pb-3 border-b border-white/8">Date Livrare</h2>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Field label="Nume Complet">
                        <input required className={inputClass} placeholder="Ion Popescu" value={form.numeComplet} onChange={e => setForm(f => ({ ...f, numeComplet: e.target.value }))} />
                      </Field>
                      <Field label="Telefon">
                        <input required className={inputClass} placeholder="07XX XXX XXX" value={form.telefon} onChange={e => setForm(f => ({ ...f, telefon: e.target.value }))} />
                      </Field>
                    </div>
                    <Field label="Email">
                      <input type="email" className={inputClass} placeholder="ion@email.ro" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
                    </Field>
                    <div className="grid grid-cols-2 gap-4">
                      <Field label="Județ">
                        <select className={inputClass} value={form.judet} onChange={e => setForm(f => ({ ...f, judet: e.target.value }))}>
                          {JUDETE.map(j => <option key={j}>{j}</option>)}
                        </select>
                      </Field>
                      <Field label="Localitate">
                        <input className={inputClass} placeholder="București" value={form.localitate} onChange={e => setForm(f => ({ ...f, localitate: e.target.value }))} />
                      </Field>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="col-span-2">
                        <Field label="Stradă">
                          <input required className={inputClass} placeholder="Str. Mihai Eminescu" value={form.strada} onChange={e => setForm(f => ({ ...f, strada: e.target.value }))} />
                        </Field>
                      </div>
                      <Field label="Număr">
                        <input required className={inputClass} placeholder="42" value={form.numar} onChange={e => setForm(f => ({ ...f, numar: e.target.value }))} />
                      </Field>
                    </div>
                    <div className="grid grid-cols-4 gap-3">
                      {[
                        { key: 'bloc', label: 'Bloc', placeholder: 'A2' },
                        { key: 'scara', label: 'Scară', placeholder: '1' },
                        { key: 'apartament', label: 'Apart.', placeholder: '14' },
                        { key: 'codInterfon', label: 'Interfon', placeholder: '1234' },
                      ].map(f => (
                        <Field key={f.key} label={f.label}>
                          <input className={inputClass} placeholder={f.placeholder} value={form[f.key]} onChange={e => setForm(prev => ({ ...prev, [f.key]: e.target.value }))} />
                        </Field>
                      ))}
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <Field label="Interval Orar">
                        <select className={inputClass} value={form.intervalOrar} onChange={e => setForm(f => ({ ...f, intervalOrar: e.target.value }))}>
                          <option value="cat-mai-curand">Cât mai curând</option>
                          <option value="12-13">12:00 – 13:00</option>
                          <option value="13-14">13:00 – 14:00</option>
                          <option value="18-19">18:00 – 19:00</option>
                          <option value="19-20">19:00 – 20:00</option>
                          <option value="20-21">20:00 – 21:00</option>
                        </select>
                      </Field>
                    </div>
                    <Field label="Instrucțiuni Livrare (opțional)">
                      <textarea rows={3} className={inputClass + ' resize-none'} placeholder="Ex: Sunați la interfon de 2 ori, nu bateți la ușă..." value={form.instructiuni} onChange={e => setForm(f => ({ ...f, instructiuni: e.target.value }))} />
                    </Field>
                  </div>
                </div>
              )}

              {/* Plată */}
              <div className="bg-[#1a1a1a] border border-white/8 rounded-[18px] p-6">
                <h2 className="font-condensed font-bold text-lg uppercase tracking-wide text-white mb-5 pb-3 border-b border-white/8">Metodă de Plată</h2>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { val: 'numerar', icon: '💵', label: 'Numerar la livrare' },
                    { val: 'card', icon: '💳', label: 'Card la livrare' },
                    { val: 'online', icon: '📱', label: 'Plată online' },
                    { val: 'applepay', icon: '🍎', label: 'Apple / Google Pay' },
                  ].map(opt => (
                    <button
                      key={opt.val} type="button"
                      onClick={() => setPayMethod(opt.val)}
                      className={`flex flex-col items-center gap-2 py-4 rounded-xl border-2 transition-all ${payMethod === opt.val ? 'border-[#c0392b] bg-[#c0392b]/10' : 'border-white/8 bg-white/3 hover:border-white/20'}`}
                    >
                      <span className="text-2xl">{opt.icon}</span>
                      <span className="text-xs font-semibold text-white text-center leading-tight">{opt.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Bacșiș */}
              <div className="bg-[#1a1a1a] border border-white/8 rounded-[18px] p-6">
                <h2 className="font-condensed font-bold text-lg uppercase tracking-wide text-white mb-5 pb-3 border-b border-white/8">Bacșiș Curier (Opțional)</h2>
                <div className="grid grid-cols-4 gap-3">
                  {[0, 5, 10, 15].map(amount => (
                    <button
                      key={amount} type="button"
                      onClick={() => setTip(amount)}
                      className={`py-3 rounded-xl border-2 font-condensed font-bold text-sm transition-all ${tip === amount ? 'border-[#c0392b] bg-[#c0392b]/10 text-[#e74c3c]' : 'border-white/8 text-[#b8a99a] hover:border-white/20'}`}
                    >
                      {amount === 0 ? 'Fără' : `${amount} lei`}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Order summary */}
            <div className="bg-[#1a1a1a] border border-white/8 rounded-[18px] p-6 sticky top-20">
              <h2 className="font-condensed font-bold text-lg uppercase tracking-wide text-white mb-5 pb-3 border-b border-white/8">Sumar Comandă</h2>

              {items.length === 0 ? (
                <p className="text-sm text-[#7a6e66] text-center py-6">Coșul este gol</p>
              ) : (
                <div className="space-y-2 mb-4">
                  {items.map(item => (
                    <div key={item.key} className="flex justify-between items-center py-2 border-b border-white/5">
                      <span className="text-sm text-[#b8a99a] flex items-center gap-2">
                        <span>{item.icon}</span>
                        <span className="truncate max-w-[160px]">{item.name} ×{item.qty}</span>
                      </span>
                      <span className="text-sm font-semibold text-white shrink-0">{(item.promo || item.price) * item.qty} lei</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Coupon */}
              <div className="flex gap-2 my-4">
                <input
                  type="text"
                  placeholder="Cod promoțional"
                  value={couponCode}
                  onChange={e => setCouponCode(e.target.value)}
                  className="flex-1 bg-white/5 border border-white/8 text-white placeholder-[#7a6e66] rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-[#c0392b]/50"
                />
                <button
                  type="button"
                  onClick={applyCoupon}
                  className="px-4 bg-white/5 border border-white/8 text-[#b8a99a] rounded-xl text-sm hover:border-[#c0392b]/40 hover:text-[#e74c3c] transition-all"
                >
                  Aplică
                </button>
              </div>

              <div className="space-y-2 border-t border-white/8 pt-4">
                <div className="flex justify-between text-sm">
                  <span className="text-[#b8a99a]">Subtotal:</span>
                  <span className="text-white">{subtotal} lei</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-[#b8a99a]">Transport:</span>
                  <span className={deliveryFee === 0 ? 'text-green-400' : 'text-white'}>{deliveryFee === 0 ? 'GRATUIT' : `${deliveryFee} lei`}</span>
                </div>
                {discountAmt > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-[#b8a99a]">Reducere:</span>
                    <span className="text-green-400">−{discountAmt} lei</span>
                  </div>
                )}
                <div className="flex justify-between text-sm">
                  <span className="text-[#b8a99a]">Bacșiș:</span>
                  <span className="text-white">{tip} lei</span>
                </div>
              </div>

              <div className="flex justify-between items-center border-t border-white/8 pt-4 mt-4">
                <span className="font-condensed font-bold text-lg uppercase text-white">Total Final:</span>
                <span className="font-bebas text-4xl text-[#f39c12]">{total} lei</span>
              </div>

              <button
                type="submit"
                className="w-full mt-5 bg-gradient-to-r from-[#c0392b] to-[#96251e] hover:from-[#e74c3c] hover:to-[#c0392b] text-white font-condensed font-bold text-xl uppercase tracking-widest py-4 rounded-xl transition-all hover:-translate-y-0.5 hover:shadow-xl hover:shadow-red-900/40"
              >
                🛵 Plasează Comanda
              </button>
              <p className="text-center text-xs text-[#7a6e66] mt-3">🔒 Date protejate și criptate</p>
            </div>
          </div>
        </form>
      </div>
      <Footer />
    </div>
  )
}
